from django.contrib import admin
from .models import Menu, MenuItem
from .models import Order

# Register your models here.
admin.site.register(Menu)
admin.site.register(MenuItem)

admin.site.register(Order)